export const categoryInfos = [
    {
      title: "Electronics",
      name: "electronics",
      imgLink:
        "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Fuji/2020/May/Dashboard/Fuji_Dash_TV_2X._SY304_CB432517900_.jpg",
    },
    {
      title: "Discover fashion trends",
      name: "women's clothing",
      imgLink:
        "https://images.unsplash.com/photo-1675881149252-a2e3d0e57e0f?w=2000&auto=format&fit=crop&q=&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGZlbWFsZSUyMGZhc2hpb258ZW58MHx8MHx8fDA%3D",
    },
    {
      title: "Men's Clothing",
      name: "men's clothing",
      imgLink:
        "https://m.media-amazon.com/images/I/618bcm65ksL._AC_UL480_FMwebp_QL65_.jpg",
    },
    {
      title: "Jewelery",
      name: "jewelery",
      imgLink:
        "https://m.media-amazon.com/images/I/71r7eWuCsaL._AC_UL480_FMwebp_QL65_.jpg",
    },
  ];
  
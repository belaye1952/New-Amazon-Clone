import image1 from './image1.jpg'
import image2 from './image2.jpg'    
import image3 from './image3.jpeg'
import image4 from './image4.jpeg'

export const img = [ image1, image2, image3, image4 ]